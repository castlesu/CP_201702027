package p195;

public class Employee 
{
	private String name;
	private int phone;
	private int money;
	
	public String getName()
	{
		return name;
	}
	public void setName(String n)
	{
		name = n;
	}
	public int getPhone()
	{
		return phone;
	}
	public void setPhone(int p)
	{
		phone = p;
	}
	public int getMoney()
	{
		return money;
	}
	public void setMoney(int m)
	{
		money = m;
	}
	
	

	
}
