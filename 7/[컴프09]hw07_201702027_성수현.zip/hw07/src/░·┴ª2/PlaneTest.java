package ����2;

public class PlaneTest {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		Plane one = new Plane("Blizzard","OVER",80);
		Plane two = new Plane();
		Plane Tre = new Plane("Con",900);
		
		int n = Plane.getPlanes();
		
		System.out.println("����� ��: "+ n);
		
	}

}
