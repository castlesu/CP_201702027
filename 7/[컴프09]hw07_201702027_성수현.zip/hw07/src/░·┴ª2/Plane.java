package ����2;

public class Plane
{	
	private String maker,model;
	private int maxP;
	private static int planes;
	
	public String getMaker()
	{
		return maker;
	}
	public void setMaker(String m)
	{
		maker = m;
	}
	public String getModel()
	{
		return model;
	}
	public void setModel(String o)
	{
		model = o;
	}
	public int getMaxP()
	{
		return maxP;
	}
	public void setMaxP(int x)
	{
		maxP = x;
	}
	
	public Plane(String maker,String model,int maxP)
	{
		this.maker = maker;
		this.model = model;
		this.maxP = maxP;
		
		planes ++;
	}
	public Plane()
	{
		maker = "APEX";
		model = "ZUNBA";
		maxP = 1000;
		
		planes++;
	}
	public Plane(String maker,int maxP)
	{
		this.maker=maker;
		this.maxP=maxP;
		model = "FLOW3R";
		
		planes++;
	}
	public static int getPlanes()
	{
		return planes;
	}
	

}
