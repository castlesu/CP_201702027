package compwork33;

public class p1333 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		int x;
		int y;
		int z;
		
		for(x=1;x<=9;x++)
		{
			if(x%2 == 0)
				continue;
			for(z=0;(10-x)/2>z;z++)
			{
				System.out.print(" ");
			}
			
			for(y=0;y<x;y++)
			{
				System.out.print("*");
			}	
			System.out.println();
			
		}
		for(x=7;x>=1;x--)
		{
			if(x%2 == 0)
				continue;
			for(z=0;(10-x)/2>z;z++)
			{
				System.out.print(" ");
			}
			
			for(y=0;y<x;y++)
			{
				System.out.print("*");
			}	
			System.out.println();
				
		}
		
	}

}
